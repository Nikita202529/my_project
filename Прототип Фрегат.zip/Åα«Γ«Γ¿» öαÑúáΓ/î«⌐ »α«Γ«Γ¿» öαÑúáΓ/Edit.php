<?php 

$ID = filter_var(trim($_POST['ID']),
FILTER_SANITIZE_STRING);
$SMP = filter_var(trim($_POST['SMP']),
FILTER_SANITIZE_STRING);
$Control = filter_var(trim($_POST['Control']),
FILTER_SANITIZE_STRING);
$Period = filter_var(trim($_POST['Period']),
FILTER_SANITIZE_STRING);
$Day = filter_var(trim($_POST['Day']),
FILTER_SANITIZE_STRING);


$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    or die("Ошибка " . mysqli_error($mysql));

$mysql -> query("UPDATE `reestr` SET `SMP` = '$SMP', `Control_Org` = '$Control', `Period` = '$Period', `Duration` = '$Day' WHERE `ID` = '$ID'");


mysqli_close($mysql);

header('Location:  Index.php');
?>