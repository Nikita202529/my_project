<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
	<title>Реестр плановых проверок</title>
</head>
<body>
	<!-- Создаем панель навигации с формой поиска -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container">
			<a href="" class="navbar-brand">Реестр плановых проверок</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false">
			<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarContent">
				<ul class="navbar-nav ms-auto mt-2 mb-2">
					<li class="nav-item">
						<a href="" class="nav-link" data-bs-toggle="modal" data-bs-target="#exampleModal">Добавить</a>
					</li>
					<li class="nav-item">
						<a href="" class="nav-link" data-bs-toggle="modal" data-bs-target="#ModalEdit">Редактировать</a>
					</li>
					<li class="nav-item">
						<a href="" class="nav-link" data-bs-toggle="modal" data-bs-target="#ModalExcel">Excel</a>
					</li>
					<li class="nav-item">
						<a href="" class="nav-link" data-bs-toggle="modal" data-bs-target="#ModalDelite">Удалить</a>
					</li>
					<li class="nav-item">
						<a href="" class="nav-link" data-bs-toggle="modal" data-bs-target="#ModalSearch">Поиск</a>
					</li>
					<li class="nav-item">
						<a href="reference.php" class="nav-link">Справка</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
<!-- Форма добавления данных -->
		<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Добавить в реестр</h5>
					<button class="btn-close" data-bs-dismiss="modal" aria-label="close"></button>
				</div>
				<div class="modal-body">
					<form action="add.php" method="post">
						<div class="row mb-3">
							<label for="inputSMP" class="col-sm-5 col-form-label ms-5">Выберите СМП</label>
							<div class="col-sm-10 ms-auto me-auto">
								<!-- Создаем поле с вариантом выборов из БД -->
								<select type="text" class="form-control" name="SMP" id="inputSMP">
								<?php
									$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    		        				or die("Ошибка " . mysqli_error($mysql));

				    		        $result = mysqli_query($mysql, "SELECT `SMP` FROM `reestr`");

    		    				     while ($SMP = $result -> fetch_assoc()) {
    		         						print_r('<option>' .'<td>' .$SMP['SMP'] .'</option>');
    		         					  }
								?>
								</select>
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputControl" class="col-sm-5 col-form-label ms-5">Контролирующий орган</label>
							<div class="col-sm-10 ms-auto me-auto">
								<select type="text" class="form-control" name="Control" id="inputControl">
								<?php
									$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    		        				or die("Ошибка " . mysqli_error($mysql));

				    		        $result = mysqli_query($mysql, "SELECT `ControlOrg` FROM `reestr`");

    		    				     while ($Control_Org = $result -> fetch_assoc()) {
    		         						print_r('<option>' .'<td>' .$ControlOrg['ControlOrg'] .'</option>');
    		         					  }
								?>
								</select>
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputTime" class="col-sm-5 col-form-label ms-5">Период</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="text" class="form-control" name="Period" id="inputPeriod">
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputDay" class="col-sm-5 col-form-label ms-5">Длительность</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="number" class="form-control" name="Day" id="inputDay">
							</div>
						</div>
						<div class="modal-footer">
							<button class="btn btn-light btn-outline-danger" data-bs-dismiss="modal">Отмена</button>		
							<button type="submit" class="btn btn-light btn-outline-success">Сохранить</button>				
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<!-- Форма добавления данных -->
<!-- Форма редактирования данных -->
		<div class="modal fade" id="ModalEdit" tabindex="-1" aria-labelledby="exampleModalEdit" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalEdit">Редактировать</h5>
					<button class="btn-close" data-bs-dismiss="modal" aria-label="close"></button>
				</div>
				<div class="modal-body">
					<form action="Edit.php" method="post">
						<div class="row mb-3">
							<label for="inputID" class="col-sm-10 col-form-label ms-5">Введите номер по списку</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="number" class="form-control" id="inputID" name="ID">
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputSMP" class="col-sm-5 col-form-label ms-5">СМП</label>
							<div class="col-sm-10 ms-auto me-auto">
								<select type="text" class="form-control" id="inputSMP" name="SMP">
								<?php
									$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    		        				or die("Ошибка " . mysqli_error($mysql));

				    		        $result = mysqli_query($mysql, "SELECT `SMP` FROM `reestr`");

    		    				     while ($SMP = $result -> fetch_assoc()) {
    		         						print_r('<option>' .'<td>' .$SMP['SMP'] .'</option>');
    		         					  }
								?>
								</select>
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputControl" class="col-sm-5 col-form-label ms-5">Контролирующий орган</label>
							<div class="col-sm-10 ms-auto me-auto">
								<select type="text" class="form-control" id="inputControl" name="Control">
								<?php
									$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    		        				or die("Ошибка " . mysqli_error($mysql));

				    		        $result = mysqli_query($mysql, "SELECT `ControlOrg` FROM `reestr`");

    		    				     while ($ControlOrg = $result -> fetch_assoc()) {
    		         						print_r('<option>' .'<td>' .$ControlOrg['ControlOrg'] .'</option>');
    		         					  }
								?>
								</select>
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputTime" class="col-sm-5 col-form-label ms-5">Период</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="text" class="form-control" id="inputPeriod" name="Period">
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputDay" class="col-sm-5 col-form-label ms-5">Длительность</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="number" class="form-control" id="inputDay" name="Day">
							</div>
						</div>
						<div class="modal-footer">
							<button class="btn btn-light btn-outline-danger" data-bs-dismiss="modal">Отмена</button>		
							<button class="btn btn-light btn-outline-success" type="submit">Сохранить</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<!-- Форма редактирования данных -->
<!-- Форма добавления данных из Excel -->
		<div class="modal fade" id="ModalExcel" tabindex="-1" aria-labelledby="exampleModalExcel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalExcel">Загрузить из Excel</h5>
					<button class="btn-close" data-bs-dismiss="modal" aria-label="close"></button>
				</div>
				<div class="modal-body">
					<form action="LoadExcel.php" method="post">
						<div class="row mb-3">
							<label for="Excel" class="col-sm-12 col-form-label ms-5">Введите название документа Excel</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="text" class="form-control" name="Excel" id="Excel">
							</div>
							<p class="col-sm-12 col-form-label ms-5">Документ должен находиться в корневой папке</p>
						</div>
						<div class="modal-footer">
							<button class="btn btn-light btn-outline-danger" data-bs-dismiss="modal">Отмена</button>		
							<button class="btn btn-light btn-outline-success" type="submit">Добавить</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<!-- Форма добавления данных из Excel -->
<!-- Форма удаления данных -->
		<div class="modal fade" id="ModalDelite" tabindex="-1" aria-labelledby="exampleModalDelite" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalDelite">Удалить данные из реестра</h5>
					<button class="btn-close" data-bs-dismiss="modal" aria-label="close"></button>
				</div>
				<div class="modal-body">
					<form action="Delete.php" method="post">
						<div class="row mb-3">
							<label for="inputID" class="col-sm-5 col-form-label ms-5">Введите номер по списку</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="number" class="form-control" id="inputID" name="ID">
							</div>
						</div>
						<div class="modal-footer">
							<button class="btn btn-light btn-outline-danger" data-bs-dismiss="modal">Отмена</button>		
							<button class="btn btn-light btn-outline-success" type="submit">Удалить</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<!-- Форма удаления данных -->
<!-- Форма поиска -->
		<div class="modal fade" id="ModalSearch" tabindex="-1" aria-labelledby="exampleModalSearch" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalSearch">Редактировать</h5>
					<button class="btn-close" data-bs-dismiss="modal" aria-label="close"></button>
				</div>
				<div class="modal-body">
					<form action="Index.php" method="post">
						<div class="row mb-3">
							<label for="inputSMP" class="col-sm-5 col-form-label ms-5">СМП</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="text" class="form-control" id="inputSMP" name="SMP">
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputControl" class="col-sm-5 col-form-label ms-5">Контролирующий орган</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="text" class="form-control" id="inputControl" name="Control">
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputTime" class="col-sm-5 col-form-label ms-5">Период</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="text" class="form-control" id="inputPeriod" name="Period">
							</div>
						</div>
						<div class="row mb-3">
							<label for="inputDay" class="col-sm-5 col-form-label ms-5">Длительность</label>
							<div class="col-sm-10 ms-auto me-auto">
								<input type="number" class="form-control" id="inputDay" name="Day">
							</div>
						</div>
						<div class="modal-footer">
							<button class="btn btn-light btn-outline-danger" data-bs-dismiss="modal">Отмена</button>		
							<button class="btn btn-light btn-outline-success" type="submit">Поиск</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<!-- Форма поиска -->
<!-- Выводим данные реестра из БД -->
	<main class="w-100">
		<h2 class="text-center my-5">Реестр плановых проверок</h2>
		<div class="container text-center w-100">
			<table class="w-100"> <!-- Создаем таблицу для вывода данных из БД -->
				<thead>
					<tr>
						<th>№</th>
						<th>Проверяемый СМП</th>
						<th>Контролирующий орган</th>
						<th>Плановый период проверки</th>
						<th>Плановая длительность</th>
					</tr>
				</thead>
				<tbody>
					<!-- PHP скрипт для вывода данных из БД -->
					<?php
					$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    		        or die("Ошибка " . mysqli_error($mysql));

    		        $result = mysqli_query($mysql, "SELECT * FROM `reestr`");

    		        /*Скрипт для формы поиска*/
    		        $ID = filter_var(trim($_POST['ID']),
					FILTER_SANITIZE_STRING);
					$SMP = filter_var(trim($_POST['SMP']),
					FILTER_SANITIZE_STRING);
					$Control = filter_var(trim($_POST['Control']),
					FILTER_SANITIZE_STRING);
					$Period = filter_var(trim($_POST['Period']),
					FILTER_SANITIZE_STRING);
					$Day = filter_var(trim($_POST['Day']),
					FILTER_SANITIZE_STRING);

					$resultSMP = mysqli_query($mysql, "SELECT * FROM `reestr` WHERE `SMP` = '$SMP'");
					$resultControl = mysqli_query($mysql, "SELECT * FROM `reestr` WHERE `ControlOrg` = '$Control'");
					$resultPeriod = mysqli_query($mysql, "SELECT * FROM `reestr` WHERE `Period` = '$Period'");
					$resultDay = mysqli_query($mysql, "SELECT * FROM `reestr` WHERE `Duration` = '$Day'");

					$i = 1;

					if ($ID == '' && $SMP == '' && $Control == '' && $Period == '' && $Day == '') {
    		         	while ($reestr = $result -> fetch_assoc()) {
    		         	print_r('<tr>' .'<td>' .$i .'</td>');
    		         	print_r('<td>' .$reestr['SMP'] .'</td>');
    		         	print_r('<td>' .$reestr['ControlOrg'] .'</td>');
    		         	print_r('<td>' .$reestr['Period'] .'</td>');
    		         	print_r('<td>' .$reestr['Duration'] .'</td>' .'</tr>');
    		         	$i++;
    		         }
    		         } else {

					while ($searchDay = $resultDay -> fetch_assoc()) {
    		         	print_r('<tr>' .'<td>' .$i .'</td>');
    		         	print_r('<td>' .$searchDay['SMP'] .'</td>');
    		         	print_r('<td>' .$searchDay['ControlOrg'] .'</td>');
    		         	print_r('<td>' .$searchDay['Period'] .'</td>');
    		         	print_r('<td style="background: #f1f1f1">' .$searchDay['Duration'] .'</td>' .'</tr>');
    		         	$i++;
    		         }

    		         while ($searchPeriod = $resultPeriod -> fetch_assoc()) {
    		         	print_r('<tr>' .'<td>' .$i .'</td>');
    		         	print_r('<td>' .$searchPeriod['SMP'] .'</td>');
    		         	print_r('<td>' .$searchPeriod['ControlOrg'] .'</td>');
    		         	print_r('<td style="background: #f1f1f1">' .$searchPeriod['Period'] .'</td>');
    		         	print_r('<td>' .$searchPeriod['Duration'] .'</td>' .'</tr>');
    		         	$i++;
    		         }

    		         while ($searchControl = $resultControl -> fetch_assoc()) {
    		         	print_r('<tr>' .'<td>' .$i .'</td>');
    		         	print_r('<td>' .$searchControl['SMP'] .'</td>');
    		         	print_r('<td style="background: #f1f1f1">' .$searchControl['ControlOrg'] .'</td>');
    		         	print_r('<td>' .$searchControl['Period'] .'</td>');
    		         	print_r('<td>' .$searchControl['Duration'] .'</td>' .'</tr>');
    		         	$i++;
    		         }

					while ($searchSMP = $resultSMP -> fetch_assoc()) {
    		         	print_r('<tr>' .'<td>' .$i .'</td>');
    		         	print_r('<td style="background: #f1f1f1">' .$searchSMP['SMP'] .'</td>');
    		         	print_r('<td>' .$searchSMP['ControlOrg'] .'</td>');
    		         	print_r('<td>' .$searchSMP['Period'] .'</td>');
    		         	print_r('<td>' .$searchSMP['Duration'] .'</td>' .'</tr>');
    		         	$i++;
    		         }
    		     }

					?>
				</tbody>
			</table>
		</div>
		<div class="container text-center mt-5">
			<form action="saveExcel.php" method="post">
			<button class="btn btn-light btn-outline-success" type="submit" onclick="myFunction()">Сохранить в Excel</button>
			</form>

			<script type="text/javascript">
				function myFunction(){
				alert('Реестр сохранится в корневую папку с сайтом!');
				}
			</script>

		</div>
	</main>
	<!-- Выводим данные реестра из базы данных -->
	<!-- Создаем футер сайта -->
		<footer class="pt-3 mt-2 my-md-5 border-top text-center bg-dark w-100">
			<div class="container"><p class="allRight">© Все права защищены</p></div>
		</footer>
	<!-- Создаем футер сайта -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
</body>
</html>