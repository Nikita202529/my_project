<?php 

$ID = filter_var(trim($_POST['ID']),
FILTER_SANITIZE_STRING);

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    or die("Ошибка " . mysqli_error($mysql));

$mysql -> query("DELETE FROM `reestr` WHERE `ID` = '$ID'");


mysqli_close($mysql);

header('Location:  Index.php');
?>