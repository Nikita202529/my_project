<?php

require_once 'PHPExcel.php';

$Excel = filter_var(trim($_POST['Excel']),
FILTER_SANITIZE_STRING);

$arrayExcel = PHPExcel_IOFactory::load(trim($Excel).'.xlsx');

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'reestr') 
    or die("Ошибка " . mysqli_error($mysql));

// Цикл по листам Excel-файла
$i = 0;
foreach ($arrayExcel->getWorksheetIterator() as $worksheet) {
    // выгружаем данные из объекта в массив
    $tables[] = $worksheet->toArray();
    $i++;
}
 
$countRow = 0;
foreach( $tables as $table ) {
    foreach($table as $row) {
        $countRow++;
    } 
}

$countProd=0;
while ($countProd<$i){
  // Данные начинаются с второй строки
  $row = 2;
  //Для СМП
  $col1 = 1;
  //Для контролирующего органа
  $col2 = 2;
  //Для периода проверки
  $col3 = 3;
  //Для длительности проверки
  $col4 = 4;
  
        $arrayExcel->setActiveSheetIndex($countProd);
	$aSheet = $arrayExcel->getActiveSheet();
	for ($row; $row <= $countRow; $row ++){
          $cell1 = $aSheet->getCellByColumnAndRow($col1, $row);
          $cell2 = $aSheet->getCellByColumnAndRow($col2, $row);
          $cell3 = $aSheet->getCellByColumnAndRow($col3, $row);
          $cell4 = $aSheet->getCellByColumnAndRow($col4, $row);
          
 
          $value1 = $cell1->getValue();
          $value2 = $cell2->getValue();
          $value3 = $cell3->getValue();
          $value4 = $cell4->getValue();

          /*Записываем данные в БД*/

          		$mysql -> query("INSERT INTO `reestr` (`SMP`, `Control_Org`, `Period`, `Duration`) 
          		VALUES('$value1', '$value2', '$value3', '$value4')");
        }

$countProd++;
}



mysqli_close($mysql);

header('Location:  Index.php');
?>